# PetalType Android Keyboard

PetalType is a native Android keyboard (IME). Android can list it alongside Gboard, so you can switch between them from the keyboard picker.

## What's included in this updated build

- Native QWERTY keyboard with number/symbol mode, shift, backspace, space, enter and emoji shortcut.
- Keyboard themes.
- Real bundled font files for the keyboard's own key labels and in-app preview: Handlee, Cabin Sketch, Patrick Hand, Architects Daughter, Comic Neue, Kalam, Indie Flower and Coming Soon.
- An **Aa** style bar that inserts Unicode text styles into the app you are typing in: Plain, Bold, Italic, Bold italic, Script, Fraktur, Double-struck, Monospace, Bubble and Small caps.
- Selecting existing text first and then choosing a style in Aa replaces that selection with the styled Unicode characters.

**Important font distinction:** the named font files change the appearance of PetalType's keys and preview. Android keyboards cannot force WhatsApp or another app to install or use those font files. To make text appear styled inside other apps, PetalType uses Unicode characters, like other font-style keyboards. Some devices/apps may render certain Unicode glyphs differently, and not every character has a styled equivalent.

## Easiest free APK build (GitHub Actions)

The APK is not built by merely opening this ZIP. The free GitHub Actions workflow in this project downloads the open font files and compiles the APK in GitHub's cloud builder. You do not need Android Studio or an Android SDK on your phone.

1. Sign in to GitHub and create a **new public or private repository** named `PetalType`.
2. On the new repository page, choose **Add file → Upload files**. Extract this ZIP first, then upload the *contents* of the `PetalTypeAndroid` folder, including the hidden `.github` folder. On a phone browser, desktop-site mode may make the upload controls easier to find.
3. Commit the upload to the `main` branch. The workflow starts automatically on that commit.
4. Open the repository's **Actions** tab and open the newest **Build PetalType APK** run.
5. When the run is successful, scroll to **Artifacts** and download **PetalType-APK**.
6. Extract the downloaded artifact ZIP. It contains `app-debug.apk`. Tap that APK in Files and approve Android's install prompt. Android may ask you to allow Files to install apps from this source.

The first cloud build may take longer than five minutes, depending on GitHub and network speed. The phone-side installation is usually just opening the APK and following Android's prompts. After the first upload, later changes pushed to `main` trigger another build automatically.

## Enable and switch to PetalType

1. Open the installed **PetalType** app.
2. Tap **Enable PetalType keyboard** and enable PetalType in Android's keyboard settings.
3. Return to PetalType and tap **Choose PetalType keyboard**.
4. Select **PetalType**.
5. In WhatsApp or another text field, use Android's keyboard switcher to move between PetalType and Gboard. The switcher location varies by phone.

## Use app-compatible text styles

1. Open a text field so PetalType appears.
2. Tap **Aa** on the keyboard's top row.
3. Choose a style. New letters and numbers are inserted using that Unicode style.
4. To style text already typed, select it in the app, bring up PetalType, tap **Aa**, then choose a style.
5. Choose **Plain** to return to ordinary text.

This project is a debug APK build. Android may show a warning because it is installed outside the Play Store. Only install APKs you built yourself or trust.
