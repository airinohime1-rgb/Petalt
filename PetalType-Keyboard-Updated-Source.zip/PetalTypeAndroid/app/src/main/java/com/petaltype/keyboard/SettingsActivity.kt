package com.petaltype.keyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.widget.*

class SettingsActivity : Activity() {
    private val fonts = listOf(
        "Handlee", "Cabin Sketch", "Patrick Hand", "Architects Daughter",
        "Comic Neue", "Kalam", "Indie Flower", "Coming Soon",
        "System Serif", "System Monospace"
    )
    private val themes = listOf(
        "Blush Garden", "Lavender Dream", "Sakura Milk", "Blueberry Sky",
        "Mint Macaron", "Buttercream", "Midnight Plum", "Dark Academia",
        "Gothic Rose", "Ocean Glass"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("petaltype", Context.MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 24)
            setBackgroundColor(Color.rgb(255,248,252))
        }
        root.addView(TextView(this).apply {
            text = "✿ PetalType"
            textSize = 28f
            setTextColor(Color.rgb(73,56,70))
            typeface = Typeface.SERIF
            gravity = Gravity.CENTER
            setPadding(0,0,0,10)
        })
        root.addView(TextView(this).apply {
            text = "Your words, your font, your little world."
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
            setPadding(0,0,0,24)
        })
        root.addView(TextView(this).apply {
            text = "Choose keyboard font"
            textSize = 16f
            setTextColor(Color.BLACK)
        })

        val preview = TextView(this).apply {
            text = "The quick brown fox · PetalType 123"
            textSize = 21f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(73,56,70))
            setPadding(8, 13, 8, 13)
            setBackgroundColor(Color.rgb(250,237,244))
        }
        val fontSpinner = Spinner(this)
        fontSpinner.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, fonts) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                return makeFontRow(position, convertView, parent)
            }
            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                return makeFontRow(position, convertView, parent)
            }
            private fun makeFontRow(position: Int, convertView: View?, parent: ViewGroup): View {
                val label = TextView(this@SettingsActivity).apply {
                    text = fonts[position]
                    textSize = 17f
                    setTextColor(Color.rgb(73,56,70))
                    setPadding(12, 12, 12, 12)
                    typeface = loadFont(fonts[position])
                }
                return label
            }
        }.also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        val currentFont = prefs.getString("font", "Handlee") ?: "Handlee"
        fontSpinner.setSelection(fonts.indexOf(currentFont).coerceAtLeast(0))
        fun updateFontPreview(position: Int) {
            val name = fonts[position]
            preview.text = "$name  ·  Aa Bb Cc 123"
            preview.typeface = loadFont(name)
            prefs.edit().putString("font", name).apply()
        }
        fontSpinner.onItemSelectedListener = SimpleSelect { updateFontPreview(it) }
        root.addView(fontSpinner)
        root.addView(preview)
        preview.contentDescription = "Preview of selected keyboard font"

        root.addView(TextView(this).apply {
            text = "Choose keyboard theme"
            textSize = 16f
            setTextColor(Color.BLACK)
            setPadding(0,20,0,0)
        })
        val themeSpinner = Spinner(this)
        themeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, themes)
        themeSpinner.setSelection(themes.indexOf(prefs.getString("theme", "Blush Garden")).coerceAtLeast(0))
        themeSpinner.onItemSelectedListener = SimpleSelect { prefs.edit().putString("theme", themes[it]).apply() }
        root.addView(themeSpinner)

        root.addView(TextView(this).apply {
            text = "Text styles for WhatsApp and other apps"
            textSize = 16f
            setTextColor(Color.BLACK)
            setPadding(0,22,0,5)
        })
        root.addView(TextView(this).apply {
            text = "Open PetalType and tap Aa to choose Plain, Bold, Italic, Script, Fraktur, Double-struck, Monospace, Bubble or Small caps. You can select existing text first, then tap a style to convert it. These use Unicode characters, so the receiving app may display some characters differently."
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(0,0,0,14)
        })

        root.addView(Button(this).apply {
            text = "Enable PetalType keyboard"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "Choose PetalType keyboard"
            setOnClickListener { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() }
        })
        root.addView(TextView(this).apply {
            text = "The font picker changes the appearance of PetalType's keys and this preview. It cannot install that font inside WhatsApp or other apps; for those, use the Unicode styles from the Aa bar."
            textSize = 12f
            setTextColor(Color.DKGRAY)
            setPadding(0,18,0,0)
        })
        setContentView(ScrollView(this).apply { addView(root) })
        // Ensure the preview reflects the saved font immediately.
        updateFontPreview(fontSpinner.selectedItemPosition.coerceAtLeast(0))
    }

    private fun loadFont(name: String): Typeface {
        val file = when (name) {
            "Handlee" -> "handlee.ttf"
            "Cabin Sketch" -> "cabin_sketch.ttf"
            "Patrick Hand" -> "patrick_hand.ttf"
            "Architects Daughter" -> "architects_daughter.ttf"
            "Comic Neue" -> "comic_neue.ttf"
            "Kalam" -> "kalam.ttf"
            "Indie Flower" -> "indie_flower.ttf"
            "Coming Soon" -> "coming_soon.ttf"
            else -> return when (name) {
                "Roboto Mono" -> Typeface.MONOSPACE
                "Playfair Display", "Cormorant Garamond" -> Typeface.SERIF
                else -> Typeface.create("casual", Typeface.NORMAL)
            }
        }
        return try { Typeface.createFromAsset(assets, "fonts/$file") }
        catch (_: Exception) { Typeface.create("casual", Typeface.NORMAL) }
    }

    private class SimpleSelect(val selected: (Int) -> Unit) : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) = selected(position)
        override fun onNothingSelected(parent: AdapterView<*>?) {}
    }
}
