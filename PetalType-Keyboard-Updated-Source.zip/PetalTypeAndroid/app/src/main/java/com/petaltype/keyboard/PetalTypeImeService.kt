package com.petaltype.keyboard

import android.inputmethodservice.InputMethodService
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView

class PetalTypeImeService : InputMethodService() {
    private var symbols = false
    private var shifted = false
    private var showStyles = false
    private var activeTextStyle = "Plain"

    private val rows get() = if (!symbols) listOf(
        listOf("q","w","e","r","t","y","u","i","o","p"),
        listOf("a","s","d","f","g","h","j","k","l"),
        listOf("⇧","z","x","c","v","b","n","m","⌫"),
        listOf("?123",",","☻","English",".","↵")
    ) else listOf(
        listOf("1","2","3","4","5","6","7","8","9","0"),
        listOf("@","#","$","%","&","-","+","(",")","/"),
        listOf("=","*","\"", "'",":",";","!","?","⌫"),
        listOf("ABC",",","☻","English",".","↵")
    )

    override fun onCreateInputView(): View = buildKeyboard()

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        symbols = false
        shifted = false
        showStyles = false
        activeTextStyle = "Plain"
    }

    private fun buildKeyboard(): View {
        val prefs = getSharedPreferences("petaltype", Context.MODE_PRIVATE)
        val theme = prefs.getString("theme", "Blush Garden") ?: "Blush Garden"
        val dark = theme in listOf("Midnight Plum", "Dark Academia", "Gothic Rose")
        val bg = if (dark) Color.rgb(40,32,45) else Color.rgb(244,222,234)
        val keyBg = if (dark) Color.rgb(74,59,79) else Color.rgb(255,248,252)
        val ink = if (dark) Color.rgb(250,239,248) else Color.rgb(73,56,70)
        val accent = if (dark) Color.rgb(180,120,157) else Color.rgb(217,142,181)
        val fontName = prefs.getString("font", "Handlee") ?: "Handlee"
        val font = loadFont(fontName)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 5, 4, 7)
            setBackgroundColor(bg)
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        val brand = TextView(this).apply {
            text = "✿  PetalType"
            textSize = 15f
            setTextColor(ink)
            typeface = font
            setPadding(8,4,8,6)
        }
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(tool("Aa", keyBg, ink) { showStyles = !showStyles; setInputView(buildKeyboard()) })
        top.addView(tool("⚙", keyBg, ink) {
            startActivity(android.content.Intent(this, SettingsActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
        })
        root.addView(top)

        if (showStyles) {
            val styleScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
            val styleLine = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            UnicodeTextStyles.names.forEach { name ->
                val selected = name == activeTextStyle
                val chip = TextView(this).apply {
                    text = if (name == "Plain") "Aa" else name
                    textSize = 12f
                    gravity = Gravity.CENTER
                    setTextColor(if (selected) Color.WHITE else ink)
                    background = GradientDrawable().apply {
                        setColor(if (selected) accent else keyBg)
                        cornerRadius = dp(14).toFloat()
                    }
                    setPadding(dp(11), dp(8), dp(11), dp(8))
                    setOnClickListener { chooseTextStyle(name) }
                }
                styleLine.addView(chip, LinearLayout.LayoutParams(-2, dp(34)).apply { setMargins(dp(3), dp(2), dp(3), dp(5)) })
            }
            styleScroll.addView(styleLine)
            root.addView(styleScroll)
        } else {
            val hint = TextView(this).apply {
                text = if (activeTextStyle == "Plain") "Tap Aa for text styles" else "Text style: $activeTextStyle  ·  Tap Aa to change"
                textSize = 10f
                setTextColor(ink)
                gravity = Gravity.CENTER
                setPadding(0, 0, 0, dp(3))
            }
            root.addView(hint)
        }

        rows.forEachIndexed { ri, row ->
            val line = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
            row.forEach { label ->
                val shown = if (label.length == 1 && !symbols && shifted) label.uppercase() else label
                val special = label.length > 1 || label in listOf("⇧", "⌫", "↵", "?123", "ABC")
                val b = Button(this).apply {
                    text = shown
                    textSize = if (label == "English") 11f else 16f
                    isAllCaps = false
                    typeface = font
                    setTextColor(if (special) Color.WHITE else ink)
                    background = GradientDrawable().apply { setColor(if (special) accent else keyBg); cornerRadius = dp(13).toFloat() }
                    setPadding(0,0,0,0)
                    minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
                    setOnClickListener { press(label) }
                }
                val weight = when(label) {
                    "English" -> 3f
                    "?123", "ABC", "⇧", "⌫", "↵" -> 1.5f
                    "☻" -> 1.1f
                    else -> 1f
                }
                val lp = LinearLayout.LayoutParams(0, if (ri == 3) dp(48) else dp(47), weight).apply {
                    setMargins(dp(2), dp(3), dp(2), dp(4))
                }
                line.addView(b, lp)
            }
            root.addView(line)
        }
        return root
    }

    private fun loadFont(name: String): Typeface {
        val file = when (name) {
            "Handlee" -> "handlee.ttf"
            "Cabin Sketch" -> "cabin_sketch.ttf"
            "Patrick Hand" -> "patrick_hand.ttf"
            "Architects Daughter" -> "architects_daughter.ttf"
            "Comic Neue" -> "comic_neue.ttf"
            "Kalam" -> "kalam.ttf"
            "Indie Flower" -> "indie_flower.ttf"
            "Coming Soon" -> "coming_soon.ttf"
            else -> return when (name) {
                "System Monospace" -> Typeface.MONOSPACE
                "System Serif" -> Typeface.SERIF
                else -> Typeface.create("casual", Typeface.NORMAL)
            }
        }
        return try { Typeface.createFromAsset(assets, "fonts/$file") }
        catch (_: Exception) { Typeface.create("casual", Typeface.NORMAL) }
    }

    private fun tool(label: String, bg: Int, ink: Int, action: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 17f
        gravity = Gravity.CENTER
        setTextColor(ink)
        background = GradientDrawable().apply { setColor(bg); cornerRadius = dp(18).toFloat() }
        setOnClickListener { action() }
        setPadding(dp(12), dp(5), dp(12), dp(5))
        val lp = LinearLayout.LayoutParams(-2, dp(35)).apply { setMargins(dp(2), 0, dp(2), 0) }
        layoutParams = lp
    }

    private fun chooseTextStyle(name: String) {
        activeTextStyle = name
        val ic = currentInputConnection
        val selected = ic?.getSelectedText(0)?.toString()
        if (!selected.isNullOrEmpty()) ic.commitText(UnicodeTextStyles.apply(selected, name), 1)
        showStyles = true
        setInputView(buildKeyboard())
    }

    private fun press(k: String) {
        val ic = currentInputConnection ?: return
        when (k) {
            "⇧" -> { shifted = !shifted; setInputView(buildKeyboard()) }
            "⌫" -> {
                val selected = ic.getSelectedText(0)
                if (!selected.isNullOrEmpty()) ic.commitText("", 1)
                else deletePreviousCodePoint(ic)
            }
            "↵" -> ic.commitText("\n",1)
            "?123" -> { symbols = true; setInputView(buildKeyboard()) }
            "ABC" -> { symbols = false; setInputView(buildKeyboard()) }
            "English" -> ic.commitText(" ",1)
            "☻" -> ic.commitText("☺",1)
            else -> {
                val raw = if (shifted) k.uppercase() else k
                ic.commitText(UnicodeTextStyles.apply(raw, activeTextStyle), 1)
                if (shifted) { shifted = false; setInputView(buildKeyboard()) }
            }
        }
    }

    private fun deletePreviousCodePoint(ic: android.view.inputmethod.InputConnection) {
        if (Build.VERSION.SDK_INT >= 24) {
            try {
                if (ic.deleteSurroundingTextInCodePoints(1, 0)) return
            } catch (_: Exception) {
                // Fall through to the UTF-16-safe compatibility path.
            }
        }
        val before = ic.getTextBeforeCursor(2, 0)?.toString().orEmpty()
        val count = if (before.length >= 2 && Character.isHighSurrogate(before[before.length - 2]) && Character.isLowSurrogate(before[before.length - 1])) 2 else 1
        if (!ic.deleteSurroundingText(count, 0)) {
            ic.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_DEL))
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
